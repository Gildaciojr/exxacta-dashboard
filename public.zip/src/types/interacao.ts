export type Interacao = {
  id: string;
  lead_id: string;
  status: string;
  observacao: string | null;
  canal: string | null;
  criado_em: string;
};
